package com.gist.bean;

/**
 * @author 高远</n> 邮箱：wgyscsf@163.com</n> 博客 http://blog.csdn.net/wgyscsf</n>
 *         编写时期 2016-4-7 下午7:24:45
 */
public class SonButton extends BaseButton {
	private String sub_button;

	public String getSub_button() {
		return sub_button;
	}

	public void setSub_button(String sub_button) {
		this.sub_button = sub_button;
	}

}
